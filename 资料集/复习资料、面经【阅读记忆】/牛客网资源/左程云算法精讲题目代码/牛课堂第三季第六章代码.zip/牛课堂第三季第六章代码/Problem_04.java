package problems_2017_08_23;

import java.util.Deque;
import java.util.LinkedList;
import java.util.Scanner;

public class Problem_04 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		while (in.hasNextInt()) {
			int n = in.nextInt();
			Deque<Integer> deque = new LinkedList<Integer>();
			boolean convert = false;
			for (int i = 0; i < n; i++) {
				if (convert) {
					deque.addLast(in.nextInt());
				} else {
					deque.addFirst(in.nextInt());
				}
				convert = !convert;
			}
			if (convert) {
				while (deque.size() != 1) {
					System.out.print(deque.pollFirst() + " ");
				}
				System.out.println(deque.pollFirst());
			} else {
				while (deque.size() != 1) {
					System.out.print(deque.pollLast() + " ");
				}
				System.out.println(deque.pollLast());
			}
		}
		in.close();
	}

}
