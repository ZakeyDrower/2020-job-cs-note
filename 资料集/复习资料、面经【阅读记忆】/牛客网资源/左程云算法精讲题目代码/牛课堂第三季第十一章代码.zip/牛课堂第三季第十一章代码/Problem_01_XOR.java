package nowcoder_2017_09_27;

import java.util.HashMap;

public class Problem_01_XOR {

	public static int mostXORs0(int[] arr) {
		int ans = Integer.MIN_VALUE;
		int xor = 0;
		int[] mosts = new int[arr.length];
		HashMap<Integer, Integer> map = new HashMap<>();
		map.put(0, -1);
		for (int i = 0; i < arr.length; i++) {
			xor ^= arr[i];
			if (map.containsKey(xor)) {
				int pre = map.get(xor);
				mosts[i] = pre == -1 ? 1 : (mosts[pre] + 1);
			}
			if (i > 0) {
				mosts[i] = Math.max(mosts[i - 1], mosts[i]);
			}
			map.put(xor, i);
			ans = Math.max(ans, mosts[i]);
		}
		return ans;
	}

	public static void main(String[] args) {
		int[] test = { 3, 0, 2, 2 };
		System.out.println(mostXORs0(test));
	}

}
